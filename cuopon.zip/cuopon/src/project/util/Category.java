package project.util;


public enum Category {
    Food
    ,Electricity
    ,Restaurant
    ,Vacation
    ,Fashion;



}

