package project.util;

public enum ClientType {
    Administartor,Company,Customer
}
