package project.exceptions;

public class CouponException extends Exception{
    public CouponException() {
    }

    public CouponException(String message) {
        super(message);
    }
}
